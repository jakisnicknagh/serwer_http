package com.zal.serwerhttp.http;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HttpVersionTest {

    @Test
    void getBestCompatibleVersionExactMatch() throws BadHttpVersionExp {
        HttpVersion version = null;
        try{
             version = HttpVersion.getBestCompVersion("HTTP/1.1");
        }catch (BadHttpVersionExp e){
            fail();
        }

        assertNotNull(version);
        assertEquals(version, HttpVersion.HTTP_1_1);
    }

    @Test
    void getBestCompatibleVersionExactFormat()  {
        HttpVersion version = null;
        try{
            version = HttpVersion.getBestCompVersion("http/1.1");
        }catch (BadHttpVersionExp e){
        }
    }

    @Test
    void getBestCompatibleVersionHigherVersion()  {
        HttpVersion version = null;
        try{
            version = HttpVersion.getBestCompVersion("HTTP/1.1");
            assertNotNull(version);
            assertEquals(version, HttpVersion.HTTP_1_1);
        }catch (BadHttpVersionExp e){
            fail();
        }
    }



}
