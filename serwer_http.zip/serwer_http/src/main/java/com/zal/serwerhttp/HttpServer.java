package com.zal.serwerhttp;

import com.zal.serwerhttp.config.Configuration;
import com.zal.serwerhttp.config.ConfigurationManager;
import com.zal.serwerhttp.core.ServerListenerThread;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Klasa dla http server
 *
 */
public class HttpServer {

    private final static Logger LOGGER = LoggerFactory.getLogger((HttpServer.class));

    public static void main(String[] args){
        LOGGER.info("Server starting...");
        ConfigurationManager.getInstance().loadConfigurationFile("src/main/resources/http.json");
        Configuration conf = ConfigurationManager.getInstance().getCurrentConfiguration();

        LOGGER.info("using Port " + conf.getPort());
        LOGGER.info("using WebRoot " + conf.getWebroot());


        try {
            ServerListenerThread serverListenerThread = new ServerListenerThread(conf.getPort(), conf.getWebroot());
            serverListenerThread.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
