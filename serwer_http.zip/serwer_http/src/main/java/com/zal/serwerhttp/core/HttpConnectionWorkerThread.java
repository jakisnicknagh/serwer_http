package com.zal.serwerhttp.core;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
//import java.util.logging.Logger;

public class HttpConnectionWorkerThread extends Thread {
    private final static Logger LOGGER  = LoggerFactory.getLogger(HttpConnectionWorkerThread.class);
    private Socket socket;

    public HttpConnectionWorkerThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run(){
        InputStream inputStream = null;
        OutputStream outputStream = null;

        try {

            inputStream =socket.getInputStream();
            outputStream=socket.getOutputStream();

//            TODO przepisac while
//            int _byte = inputStream.read();
//
//            while ((_byte = inputStream.read()) >= 0 ){
//                System.out.print((char) _byte);
//
//            }

            String html = "<html><head><title>Prosty serwer HTTP java</title></head><body>testtowa strona dla serwera http</body></html>";

            final String CRFL = "\n\r"; //13,10

            String response =
                    "HTTP/1.1 200 OK" + CRFL +// Status HTTP version responce code
                            "Content-Lenght:" + html.getBytes().length + CRFL +  // HEADER
                            CRFL +
                            html +
                            CRFL + CRFL;

            outputStream.write(response.getBytes());



            LOGGER.info("Connection Processing Finished");


        } catch (IOException e) {
            LOGGER.error("Problem with communication", e);
        } finally {
            if (inputStream != null){
                try{
                    inputStream.close();
                }catch (IOException e){};
            }
            if (outputStream!=null){
                try {
                    outputStream.close();
                }catch (IOException e){};
            }
            if (socket!=null){
                try{
                    socket.close();
                }catch (IOException e){};
            }
        }
    }

    }
