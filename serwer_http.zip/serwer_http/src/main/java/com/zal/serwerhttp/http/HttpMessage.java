package com.zal.serwerhttp.http;

public abstract class HttpMessage {



}
