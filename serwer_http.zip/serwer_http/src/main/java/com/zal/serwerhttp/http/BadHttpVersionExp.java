package com.zal.serwerhttp.http;

public class BadHttpVersionExp extends Exception{



}
